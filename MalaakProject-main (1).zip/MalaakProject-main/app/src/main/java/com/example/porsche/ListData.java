package com.example.porsche;

public class ListData {
    String name, time;
    int ingredients, desc;
    int image;

    public ListData(String name,int image) {
        this.name = name;
        this.image = image;
    }
}
